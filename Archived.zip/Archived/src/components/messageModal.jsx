import { useState } from "react";

export const MessageModal = () => {
  const [openMessageModal, setMessageModal] = useState(false);

  useEffect = () => {};

  return (
    <div>
      <div>Modal For Message Pop up</div>
    </div>
  );
};
